package com.example.mytask

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View


class BoxView(context: Context): View(context) {
    private var color:BoxColor = BoxColor.WHITE
    fun setColor(color:BoxColor){
        this.color = color
        contentDescription = color.name
        invalidate()
    }
    fun getColor(): BoxColor {
        return color
    }

    override fun onDraw(canvas: Canvas?) {
        super.onDraw(canvas)
        val paint = Paint()
        paint.color = color.colorValue
        paint.style = Paint.Style.FILL
        canvas?.drawRect(0f,0f,width.toFloat(),height.toFloat(),paint)
    }
}
enum class BoxColor(val colorValue:Int){
    WHITE(Color.WHITE),
    BLUE(Color.BLUE),
    RED(Color.RED)

}
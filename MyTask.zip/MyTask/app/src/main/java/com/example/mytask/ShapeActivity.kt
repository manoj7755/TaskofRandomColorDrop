package com.example.mytask

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.TextView
import com.example.mytask.BoxColor.WHITE
import java.util.ArrayList
import kotlin.math.sqrt

class ShapeActivity : AppCompatActivity() {
    lateinit var boxesLayout:GridLayout
    var userInput = 0
    private  var blueBoxIndex = -1
    private  var gameOver = false
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)



        setContentView(R.layout.activity_shape)
        userInput = intent.getIntExtra("input_num",1)
        boxesLayout= findViewById<GridLayout>(R.id.boxesLayout)
        generateBox(userInput)

    }

    private fun generateBox(userInput: Int) {
   boxesLayout.columnCount = sqrt(userInput.toDouble()).toInt()
        for (i in 0 until userInput){
            val box = BoxView(this)
            box.setOnClickListener {
            onBoxCLinked(box,i)

            }
            boxesLayout.addView(box)
        }
        blueBoxIndex = (0 until userInput).random()
        boxesLayout.getChildAt(blueBoxIndex).setBackgroundColor(Color.BLUE)
    }

    private fun onBoxCLinked(box: BoxView, index: Int) {
 if (!gameOver && blueBoxIndex == index){
     box.setColor(BoxColor.RED)
     boxesLayout.getChildAt(blueBoxIndex).setBackgroundColor(Color.WHITE)
     blueBoxIndex = (0 until userInput).filter {
         it != blueBoxIndex && boxesLayout.getChildAt(it).solidColor == Color.WHITE}.random()
//     boxesLayout.getChildAt(blueBoxIndex).
     if (boxesLayout.findViewsWithText(
             ArrayList(),
             BoxColor.BLUE.name,
             View.FIND_VIEWS_WITH_CONTENT_DESCRIPTION)==null){
         gameOver = false

     }
 }
    }



}



